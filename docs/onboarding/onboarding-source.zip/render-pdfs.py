#!/usr/bin/env python3
"""Render the Policy to Action onboarding PDFs from their HTML sources.

Usage: python3 render-pdfs.py
Requires: pip install weasyprint

The HTML files are the canonical layout sources. The .md files are
content mirrors for quick editing and review; apply approved wording
changes to the matching HTML file (the text is identical), then run
this script to regenerate the finished PDFs.
"""

import weasyprint

DOCUMENTS = {
    "quickstart-participants.html": "Policy-to-Action-Quick-Start-Participants.pdf",
    "quickstart-admins.html": "Policy-to-Action-District-Setup-Guide.pdf",
    "quickstart-customers.html": "Policy-to-Action-District-Onboarding-Overview.pdf",
    "user-manual.html": "Policy-to-Action-User-Manual.pdf",
    "video-script.html": "Policy-to-Action-Video-Script.pdf",
}

for source, output in DOCUMENTS.items():
    weasyprint.HTML(source).write_pdf(output)
    print(f"rendered {output}")
